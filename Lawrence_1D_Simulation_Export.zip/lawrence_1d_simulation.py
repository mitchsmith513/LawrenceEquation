
import numpy as np
import matplotlib.pyplot as plt

# Core evolution function
def evolve_lawrence_psi(psi, H, dt, alpha=1.0, gamma=0.0, decoherence_mask=None):
    i_alpha = (1j)**alpha
    dpsi_unitary = -i_alpha * H @ psi
    dpsi_decoh = -gamma * (1 - decoherence_mask) * psi if (gamma > 0 and decoherence_mask is not None) else 0
    psi_new = psi + dt * (dpsi_unitary + dpsi_decoh)
    return psi_new / np.sqrt(np.sum(np.abs(psi_new)**2))

# 1D domain setup
N = 256
L = 10.0
x = np.linspace(-L/2, L/2, N)
dx = x[1] - x[0]
dt = 0.005
T = 1.5
steps = int(T / dt)

# Initial wavefunction (Gaussian)
x0, sigma, k0 = -2.0, 0.5, 5.0
psi = np.exp(-(x - x0)**2 / (2 * sigma**2)) * np.exp(1j * k0 * x)
psi /= np.sqrt(np.sum(np.abs(psi)**2) * dx)

# Hamiltonian
laplacian = (-2 * np.eye(N) + np.eye(N, 1) + np.eye(N, -1)) / dx**2
H = -0.5 * laplacian

# Decoherence mask
decoherence_mask = np.ones_like(x)
decoherence_mask[np.abs(x) < 1.0] = 0

# Entropy tracking
entropy_trace = []
psi0 = psi.copy()

for _ in range(steps):
    rho = np.outer(psi, np.conj(psi))
    p_diag = np.real(np.diag(rho))
    p_diag = p_diag[p_diag > 1e-10]
    S = -np.sum(p_diag * np.log(p_diag))
    entropy_trace.append(S)
    psi = evolve_lawrence_psi(psi, H, dt, alpha=1.0, gamma=0.5, decoherence_mask=decoherence_mask)

# Plot
fig, axs = plt.subplots(2, 1, figsize=(10, 6))
axs[0].plot(x, np.abs(psi0)**2, label="Initial |ψ|²")
axs[0].plot(x, np.abs(psi)**2, label="Final |ψ|²", linestyle='--')
axs[0].set_title("Probability Density |ψ(x)|²")
axs[0].legend()
axs[1].plot(np.linspace(0, T, steps), entropy_trace, color='orange')
axs[1].set_title("Entropy S(ρ) Over Time")
axs[1].set_xlabel("Time")
axs[1].set_ylabel("Entropy")
plt.tight_layout()
plt.savefig("/mnt/data/lawrence_1d_entropy_plot.png")
plt.show()
